package com.gabi.assistant.voice

import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.mockwebserver.*
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.io.IOException

class CancellableAudioDownloadTest {
    @Test fun cancelsWhileWaitingForHeaders() = runBlocking {
        MockWebServer().use { server ->
            server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
            val call = OkHttpClient().newCall(Request.Builder().url(server.url("/audio")).build())
            val task = async { call.awaitAudioBytes() }
            val received = withContext(Dispatchers.IO) { server.takeRequest(3, TimeUnit.SECONDS) }
            assertNotNull(received)
            withTimeout(3000L) { task.cancelAndJoin() }
            assertTrue(task.isCancelled)
            assertTrue(call.isCanceled())
        }
    }

    @Test fun cancelsWhileReadingSlowBody() = runBlocking {
        MockWebServer().use { server ->
            val reading = CountDownLatch(1)
            server.enqueue(MockResponse().setBody("audio".repeat(1000)).throttleBody(1, 1, TimeUnit.SECONDS))
            val client = OkHttpClient.Builder().eventListener(object : EventListener() {
                override fun responseBodyStart(call: Call) { reading.countDown() }
            }).build()
            val call = client.newCall(Request.Builder().url(server.url("/audio")).build())
            val task = async { call.awaitAudioBytes() }
            val began = withContext(Dispatchers.IO) { reading.await(3, TimeUnit.SECONDS) }
            assertTrue(began)
            withTimeout(3000L) { task.cancelAndJoin() }
            assertTrue(task.isCancelled)
            assertTrue(call.isCanceled())
        }
    }

    @Test fun readsBodyAndRejectsHttpFailureAndEmptyAudio() = runBlocking {
        MockWebServer().use { server ->
            val client = OkHttpClient()
            server.enqueue(MockResponse().setBody("audio"))
            val bytes = client.newCall(Request.Builder().url(server.url("/audio")).build()).awaitAudioBytes()
            assertEquals("audio", bytes.decodeToString())
            for (response in listOf(MockResponse().setResponseCode(401), MockResponse().setBody(""))) {
                server.enqueue(response)
                try {
                    client.newCall(Request.Builder().url(server.url("/audio")).build()).awaitAudioBytes()
                    fail("Expected failure")
                } catch (_: IOException) { }
            }
        }
    }
}
