package com.gabi.assistant.ai

import com.google.gson.annotations.SerializedName
import com.gabi.assistant.data.model.AiMessage
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

data class DsRequest(
    val model: String,
    val messages: List<DsMessage>,
    val temperature: Float,
    @SerializedName("max_tokens") val maxTokens: Int
)

data class DsMessage(val role: String, val content: String)
data class DsResponse(val choices: List<DsChoice>)
data class DsChoice(val message: DsMessage)

interface DeepSeekApi {
    @POST("v1/chat/completions")
    suspend fun chat(
        @Header("Authorization") auth: String,
        @Body request: DsRequest
    ): DsResponse

    @POST("v1/chat/completions")
    suspend fun chatWithTools(
        @Header("Authorization") auth: String,
        @Body request: ToolChatRequest
    ): ToolChatResponse
}

@Singleton
class DeepSeekProvider @Inject constructor() : AiModelProvider {

    private suspend fun <T> timedAi(kind: String, block: suspend () -> T): T {
        val trace = com.gabi.assistant.voice.GabiLatency.current()
        trace?.mark("ai_request_start", "provider=DeepSeek kind=$kind")
        return try {
            block().also { trace?.mark("ai_response", "kind=$kind") }
        } catch (e: kotlinx.coroutines.CancellationException) {
            trace?.mark("ai_cancelled", "kind=$kind")
            throw e
        } catch (e: Exception) {
            trace?.mark("ai_error", "kind=$kind")
            throw e
        }
    }

    override val name = "DeepSeek"

    var apiKey: String = ""

    private val api: DeepSeekApi by lazy {
        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl("https://api.deepseek.com/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DeepSeekApi::class.java)
    }

    override suspend fun chat(
        messages: List<AiMessage>,
        systemPrompt: String,
        temperature: Float,
        maxTokens: Int
    ): Result<String> {
        return try {
            val allMessages = mutableListOf(DsMessage("system", systemPrompt)) +
                    messages.map { DsMessage(it.role, it.content) }

            val response = timedAi("chat") { api.chat(
                auth = "Bearer $apiKey",
                request = DsRequest(
                    model = "deepseek-chat",
                    messages = allMessages,
                    temperature = temperature,
                    maxTokens = maxTokens
                )
            ) }
            val content = response.choices.firstOrNull()?.message?.content
                ?: return Result.failure(Exception("Empty response from DeepSeek"))
            Result.success(content.trim())
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun chatWithTools(
        messages: List<AiMessage>,
        systemPrompt: String,
        tools: List<ToolDef> = GabiTools.definitions
    ): Result<ToolMessage> {
        return try {
            val allMessages = mutableListOf(ToolMessage(role = "system", content = systemPrompt)) +
                    messages.map { ToolMessage(role = it.role, content = it.content) }

            val response = timedAi("chatWithTools") { api.chatWithTools(
                auth = "Bearer $apiKey",
                request = ToolChatRequest(
                    model = "deepseek-chat",
                    messages = allMessages,
                    tools = tools,
                    temperature = 0.3f,
                    maxTokens = 1024
                )
            ) }
            val message = response.choices.firstOrNull()?.message
                ?: return Result.failure(Exception("Empty response from DeepSeek"))
            Result.success(message)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
