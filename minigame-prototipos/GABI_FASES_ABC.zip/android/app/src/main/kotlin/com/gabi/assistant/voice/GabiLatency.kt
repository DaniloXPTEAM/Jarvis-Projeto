package com.gabi.assistant.voice

import android.os.SystemClock
import android.util.Log
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.coroutineContext

/** No text, prompts or credentials are logged. Times are monotonic. */
class GabiLatency : AbstractCoroutineContextElement(Key) {
    companion object Key : CoroutineContext.Key<GabiLatency> {
        private val ids = AtomicLong()
        suspend fun current(): GabiLatency? = coroutineContext[Key]
    }
    val id = ids.incrementAndGet()
    private val origin = SystemClock.elapsedRealtime()
    fun mark(event: String, detail: String = "") {
        Log.i("GABI_LATENCY", "[GABI_LATENCY] turn=$id event=$event t_ms=${SystemClock.elapsedRealtime()} elapsed_ms=${SystemClock.elapsedRealtime() - origin} $detail")
    }
}
