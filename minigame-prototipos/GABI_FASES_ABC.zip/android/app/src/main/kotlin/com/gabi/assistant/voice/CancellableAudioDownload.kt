package com.gabi.assistant.voice

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import java.io.IOException
import kotlin.coroutines.resume

/** The cancellation handler covers both waiting for headers and reading the body. */
internal suspend fun Call.awaitAudioBytes(): ByteArray = suspendCancellableCoroutine { cont ->
    val call = this@awaitAudioBytes
    cont.invokeOnCancellation { call.cancel() }
    call.enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWith(Result.failure(e))
        }
        override fun onResponse(call: Call, response: Response) {
            // OkHttp worker thread, never the main thread. Close in every outcome.
            try {
                val bytes = response.use {
                    if (!it.isSuccessful) throw IOException("ElevenLabs HTTP ${it.code}")
                    val audio = it.body?.bytes() ?: throw IOException("Áudio ausente")
                    if (audio.isEmpty()) throw IOException("Áudio vazio")
                    audio
                }
                if (cont.isActive) cont.resume(bytes)
            } catch (e: Exception) {
                // Closing a socket after voluntary cancellation must not become an error.
                if (cont.isActive) cont.resumeWith(Result.failure(e))
            }
        }
    })
}
