package com.gabi.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

@Singleton
class AndroidTtsFallback @Inject constructor(
    @ApplicationContext private val context: Context
) : GabiTtsEngine {
    private var tts: TextToSpeech? = null
    // Iniciar o motor é assíncrono (callback do Android) — sem isso, um speak() chamado
    // antes do callback terminar (ex.: a saudação, logo ao abrir o app) desistia
    // SILENCIOSAMENTE, sem erro nenhum: causa raiz de "não sai som nenhum" em 21/08/2026.
    private val readyState = CompletableDeferred<Boolean>()
    @Volatile private var initialized = false
    var speechRate: Float = 1.0f
    var pitch: Float = 1.05f   // leve realce; a seleção de voz já resolve o timbre feminino

    init { initTts() }

    /**
     * O motor "Google Text-to-Speech" (com.google.android.tts) traz vozes neurais de
     * qualidade bem superior às de outros fabricantes (Samsung, etc.), que costumam soar
     * robóticas. Se o Google TTS estiver instalado, usamos ele explicitamente em vez do
     * motor padrão do sistema (que pode ser outro).
     */
    private fun preferredEngine(): String? = try {
        context.packageManager.getPackageInfo(GOOGLE_TTS_PACKAGE, 0)
        GOOGLE_TTS_PACKAGE
    } catch (e: Exception) {
        null
    }

    private fun initTts() {
        val engine = preferredEngine()
        val onInit = TextToSpeech.OnInitListener { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Tenta pt-BR, mas mesmo se o pacote de idioma não estiver instalado no
                // aparelho (LANG_MISSING_DATA), ainda marca pronto — falar com o idioma
                // padrão do motor é melhor do que ficar em silêncio total pra sempre.
                tts?.setLanguage(Locale("pt", "BR"))
                selectBestVoice()
                tts?.setSpeechRate(speechRate)
                tts?.setPitch(pitch)
                initialized = true
                readyState.complete(true)
            } else {
                readyState.complete(false)
            }
        }
        tts = if (engine != null) TextToSpeech(context, onInit, engine) else TextToSpeech(context, onInit)
    }

    /**
     * Escolhe a melhor voz pt-BR disponível no motor, priorizando qualidade
     * (Voice.quality: VERY_HIGH > HIGH > NORMAL > LOW > VERY_LOW) — é essa qualidade,
     * não o pitch, que faz a diferença entre uma voz natural e uma robótica. Entre vozes
     * empatadas em qualidade, prioriza nomes que sugerem timbre feminino.
     */
    private fun selectBestVoice() {
        val voices = tts?.voices ?: return
        val ptBrVoices = voices.filter { v ->
            val loc = v.locale
            loc != null && loc.language == "pt" && loc.country == "BR"
        }
        if (ptBrVoices.isEmpty()) return

        val best = ptBrVoices
            .sortedWith(
                compareByDescending<Voice> { it.quality }
                    .thenByDescending { v ->
                        v.name.contains("female", ignoreCase = true) ||
                            v.name.contains("pt-br-x", ignoreCase = true)
                    }
            )
            .firstOrNull()

        best?.let { tts?.voice = it }
    }

    @Volatile private var activeJob: kotlinx.coroutines.Job? = null
    @Volatile private var speaking = false

    override fun isReady() = initialized && tts != null
    override suspend fun initialize(): Result<Unit> {
        val ready = withTimeoutOrNull(5000L) { readyState.await() } ?: false
        return if (ready && tts != null) Result.success(Unit)
        else Result.failure(IllegalStateException("Android TTS indisponível"))
    }

    override suspend fun speak(text: String, onAudioStarted: (() -> Unit)?): Result<Unit> = kotlinx.coroutines.coroutineScope {
        val owner = kotlinx.coroutines.currentCoroutineContext()[kotlinx.coroutines.Job]!!
        activeJob?.cancel(kotlinx.coroutines.CancellationException("Superseded"))
        activeJob = owner
        val trace = GabiLatency.current() ?: GabiLatency()
        try {
            trace.mark("tts_request", "engine=android")
            initialize().getOrThrow()
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                val engine = tts ?: error("Android TTS indisponível")
                val done = CompletableDeferred<Unit>()
                val id = "gabi_${java.util.UUID.randomUUID()}"
                val audioReported = java.util.concurrent.atomic.AtomicBoolean(false)
                try {
                    engine.setSpeechRate(speechRate); engine.setPitch(pitch)
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onBeginSynthesis(u: String?, rate: Int, format: Int, channels: Int) {
                            if (u == id && done.isActive) trace.mark("synthesis_start", "engine=android")
                        }
                        override fun onAudioAvailable(u: String?, audio: ByteArray?) {
                            if (u == id && done.isActive && audio != null && audio.isNotEmpty() && audioReported.compareAndSet(false, true)) trace.mark("audio_available", "engine=android")
                        }
                        override fun onStart(u: String?) {
                            if (u == id && done.isActive && owner.isActive) {
                                speaking = true
                                trace.mark("playback_start", "engine=android")
                                onAudioStarted?.invoke()
                            }
                        }
                        override fun onDone(u: String?) { if (u == id) done.complete(Unit) }
                        override fun onError(u: String?) { if (u == id) done.completeExceptionally(IllegalStateException("Android TTS playback error")) }
                        override fun onError(u: String?, code: Int) { if (u == id) done.completeExceptionally(IllegalStateException("Android TTS error $code")) }
                        override fun onStop(u: String?, interrupted: Boolean) { if (u == id) done.cancel(kotlinx.coroutines.CancellationException("Speech stopped")) }
                    })
                    if (engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.ERROR)
                        error("Android TTS rejeitou a fala")
                    val watchdog = 30_000L + text.length * 500L
                    if (withTimeoutOrNull(watchdog) { done.await(); true } != true)
                        error("Android TTS completion timeout")
                    trace.mark("playback_end", "engine=android")
                } finally {
                    done.cancel()
                    engine.setOnUtteranceProgressListener(null)
                    engine.stop()
                }
            }
            Result.success(Unit)
        } catch (e: kotlinx.coroutines.CancellationException) {
            trace.mark("tts_cancelled", "engine=android")
            throw e
        } catch (e: Exception) {
            trace.mark("tts_error", "engine=android type=${e.javaClass.simpleName}")
            Result.failure(e)
        } finally {
            if (activeJob === owner) { activeJob = null; speaking = false }
        }
    }

    override fun stop() { activeJob?.cancel(kotlinx.coroutines.CancellationException("Speech stopped")); speaking = false }
    override fun isSpeaking() = speaking

    fun release() {
        stop()
        tts?.stop()
        tts?.shutdown()
        tts = null
        initialized = false
    }

    companion object {
        private const val GOOGLE_TTS_PACKAGE = "com.google.android.tts"
    }
}
