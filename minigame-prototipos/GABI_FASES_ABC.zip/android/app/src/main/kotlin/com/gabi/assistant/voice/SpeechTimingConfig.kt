package com.gabi.assistant.voice

import android.content.Context

/** Debug-only A/B overrides. Production and absent overrides preserve the baseline. */
data class SpeechTimingConfig(val completeMs: Long, val possibleMs: Long) {
    companion object {
        const val BASELINE_COMPLETE_MS = 2500L
        const val BASELINE_POSSIBLE_MS = 1800L
        fun load(context: Context): SpeechTimingConfig {
            if (!com.gabi.assistant.BuildConfig.DEBUG) return SpeechTimingConfig(BASELINE_COMPLETE_MS, BASELINE_POSSIBLE_MS)
            val p = context.getSharedPreferences("gabi_speech_ab", Context.MODE_PRIVATE)
            val complete = p.getLong("complete_ms", BASELINE_COMPLETE_MS).coerceIn(500L, 5000L)
            val possible = p.getLong("possible_ms", BASELINE_POSSIBLE_MS).coerceIn(250L, complete)
            return SpeechTimingConfig(complete, possible)
        }
    }
}
