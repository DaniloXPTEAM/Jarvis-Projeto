package com.gabi.assistant.voice

interface GabiTtsEngine {
    suspend fun initialize(): Result<Unit>
    /** Suspends until playback ends. Cancellation is thrown, never returned as failure. */
    suspend fun speak(text: String, onAudioStarted: (() -> Unit)? = null): Result<Unit>
    fun stop()
    fun isSpeaking(): Boolean
    fun isReady(): Boolean
}
