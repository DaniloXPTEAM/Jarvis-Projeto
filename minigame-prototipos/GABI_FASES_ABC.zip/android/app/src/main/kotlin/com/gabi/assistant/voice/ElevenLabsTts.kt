package com.gabi.assistant.voice

import android.content.Context
import android.media.MediaPlayer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ElevenLabsTts @Inject constructor(@ApplicationContext private val context: Context) : GabiTtsEngine {
    @Volatile private var activeJob: Job? = null
    @Volatile private var speaking = false
    @Volatile private var activeCall: Call? = null
    var apiKey: String = ""
    var voiceId: String = DEFAULT_VOICE_ID
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS).callTimeout(90, TimeUnit.SECONDS).build()

    override fun isReady() = apiKey.isNotBlank()
    override fun isSpeaking() = speaking
    override suspend fun initialize(): Result<Unit> = if (isReady()) Result.success(Unit)
        else Result.failure(IllegalStateException("Chave ElevenLabs vazia"))

    @OptIn(ExperimentalCoroutinesApi::class)
    override suspend fun speak(text: String, onAudioStarted: (() -> Unit)?): Result<Unit> = coroutineScope {
        val owner = currentCoroutineContext()[Job]!!
        activeJob?.cancel(CancellationException("Superseded"))
        activeJob = owner
        val trace = GabiLatency.current() ?: GabiLatency()
        var file: File? = null
        try {
            initialize().getOrThrow()
            trace.mark("tts_request", "engine=elevenlabs")
            val body = JSONObject().apply {
                put("text", text); put("model_id", "eleven_turbo_v2_5"); put("language_code", "pt")
                put("voice_settings", JSONObject().apply {
                    put("stability", 0.5); put("similarity_boost", 0.75)
                    put("style", 0.3); put("use_speaker_boost", true)
                })
            }.toString().toRequestBody("application/json".toMediaType())
            val call = client.newCall(Request.Builder()
                .url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId")
                .header("xi-api-key", apiKey).header("Accept", "audio/mpeg").post(body).build())
            activeCall = call
            try {
                val bytes = call.awaitAudioBytes()
                withContext(Dispatchers.IO) {
                    ensureActive()
                    file = File.createTempFile("gabi_tts_", ".mp3", context.cacheDir)
                    file!!.writeBytes(bytes)
                }
            } finally { if (activeCall === call) activeCall = null }
            trace.mark("audio_available", "engine=elevenlabs")
            play(file!!, trace, onAudioStarted)
            Result.success(Unit)
        } catch (e: CancellationException) {
            trace.mark("tts_cancelled", "engine=elevenlabs")
            throw e
        } catch (e: Exception) {
            trace.mark("tts_error", "engine=elevenlabs type=${e.javaClass.simpleName}")
            Result.failure(e)
        } finally {
            file?.delete()
            if (activeJob === owner) { activeJob = null; speaking = false }
        }
    }

    private suspend fun play(file: File, trace: GabiLatency, started: (() -> Unit)?) = withContext(Dispatchers.Main) {
        val player = MediaPlayer()
        val prepared = CompletableDeferred<Unit>()
        val completed = CompletableDeferred<Unit>()
        try {
            player.setDataSource(file.absolutePath)
            player.setOnPreparedListener { prepared.complete(Unit) }
            player.setOnCompletionListener { completed.complete(Unit) }
            player.setOnErrorListener { _, what, extra ->
                val error = IOException("MediaPlayer error $what/$extra")
                prepared.completeExceptionally(error); completed.completeExceptionally(error); true
            }
            player.prepareAsync()
            if (withTimeoutOrNull(15_000L) { prepared.await(); true } != true)
                throw IOException("MediaPlayer preparation timeout")
            player.start()
            speaking = true
            trace.mark("playback_start", "engine=elevenlabs")
            started?.invoke()
            // Duration plus grace replaces the old 20s limit. Still guards a missing completion callback.
            val watchdogMs = player.duration.coerceAtLeast(0).toLong() + 15_000L
            if (withTimeoutOrNull(watchdogMs) { completed.await(); true } != true)
                throw IOException("MediaPlayer completion timeout")
            trace.mark("playback_end", "engine=elevenlabs")
        } finally {
            speaking = false
            player.setOnPreparedListener(null); player.setOnCompletionListener(null); player.setOnErrorListener(null)
            player.release()
        }
    }
    override fun stop() { activeJob?.cancel(CancellationException("Speech stopped")); activeCall?.cancel(); speaking = false }
    fun stopSpeaking() = stop()
    companion object {
        const val DEFAULT_VOICE_ID = "RGymW84CSmfVugnA5tvA"
        const val VOICE_ROBERTA = DEFAULT_VOICE_ID
        const val VOICE_RAQUEL = "GDzHdQOi6jjf8zaXhCYD"
        const val VOICE_KEREN = "33B4UnXyTNbgLmdEDh5P"
        const val VOICE_CARLA = "eVXYtPVYB9wDoz9NVTIy"
        const val VOICE_ANA_DIAS = "MZxV5lN3cv7hi1376O0m"
    }
}
