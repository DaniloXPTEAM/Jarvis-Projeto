# Gabi — entrega das Fases A, B e C

## Escopo e validação

Somente instrumentação, configuração A/B e adaptação dos motores existentes.
Não há Pocket TTS, modelos, clonagem, streaming de IA, streaming de ElevenLabs ou barge-in novo.
ElevenLabs ainda baixa o MP3 completo; isso foi preservado nesta etapa para permitir medir o gargalo.
Animações, referências de voz, DirectReply, comandos e ordem de fallback da IA foram preservados.

**Compilação concluída e testes aprovados:** Gradle 8.9, SDK Android 34 e JDK Temurin 17 completo foram instalados. `assembleDebug` e `testDebugUnitTest` terminaram com BUILD SUCCESSFUL; seis testes passaram.
Foram executados três testes existentes de estado do avatar e três novos testes HTTP: cancelamento antes dos cabeçalhos, cancelamento durante leitura lenta e validação de sucesso/HTTP inválido/áudio vazio.
O teste de leitura lenta encontrou uma falha em que fechar o socket podia promover cancelamento a erro comum; o download agora mantém uma única continuação cancelável durante toda a leitura no worker OkHttp.
Os testes instrumentados de vídeo e os testes de microfone/latência real no celular ainda não foram executados.
O gradlew original apresenta CRLF e argumentos JVM agrupados incorretamente no Linux e foi preservado. Use Android Studio, gradlew.bat no Windows ou o executável Gradle 8.9 instalado. Confira também org.gradle.java.home no gradle.properties: o original aponta para um caminho Windows; ajuste ao seu JDK 17.
No ambiente de teste foi usado um build limpo com --no-build-cache --rerun-tasks -Pksp.incremental=false -Pkotlin.incremental=false para evitar conflitos do KSP com arquivos gerados.

### Pocket TTS testado separadamente

Código oficial: https://github.com/kyutai-labs/pocket-tts — commit 1b128439b9bc74fc35d7c90694dce0e029059de3, versão 3.3.0, PyTorch CPU 2.8.0.
Geração com modelo português e voz padrão Rafael funcionou, incluindo exportar/recarregar perfil. As quatro frases foram geradas novamente com HF_HUB_OFFLINE=1. O primeiro chunk levou entre 98 e 131 ms nesse teste Linux CPU. Isso não é latência do aplicativo nem medição Android; não avalia a naturalidade da voz subjetivamente.
Os resultados e áudios estão em resultados/.
A tentativa com voz-teste/gabi_24l.wav falhou porque os pesos com clonagem exigem aceitar os termos e autenticar acesso em https://huggingface.co/kyutai/pocket-tts. O modelo público sem clonagem permite as vozes do catálogo, não a referência da Gabi.
A página informa que o acesso requer concordar com o compartilhamento de informações de contato. Não há token nem credencial incluídos neste pacote.
Licenças consultadas: código MIT; modelo oficial CC-BY-4.0 com condições de acesso/uso na página acima. Pesos e runtime não foram integrados ao APK ABC.

## Aplicar

Faça uma cópia de segurança do projeto original. Copie a pasta `android` deste pacote por cima da pasta `android` do projeto completo, aceitando a substituição dos oito arquivos indicados em `arquivos_modificados.txt`.
Este pacote contém **somente as alterações**, não inclui assets, áudios, credenciais ou dependências do projeto original.
Há cinco arquivos Kotlin novos: quatro no código principal e um de testes. `alteracoes.patch` mostra o diff completo do código.
Abra `android` no Android Studio, confira o SDK 34 e Java 17 e execute assembleDebug (ou, no Windows, `gradlew.bat :app:assembleDebug`).
Não substitua seu local.properties; mantenha suas chaves e configure sdk.dir para o SDK instalado.

## Mudanças de comportamento

- GabiTtsEngine oferece initialize, speak, stop, isSpeaking e isReady. speak suspende até terminar e retorna Result; CancellationException é propagada.
- ElevenLabsTts e AndroidTtsFallback implementam a interface. O repositório mantém a escolha entre ElevenLabs e Android; nenhum motor novo foi adicionado.
- isSpeaking muda para true no start do MediaPlayer ou onStart do Android TTS, e volta a false em conclusão, erro ou parada.
- Cada fala é serializada; uma nova fala cancela a anterior antes de assumir o motor.
- Cancelamento cancela a requisição HTTP, a leitura do corpo, a espera de reprodução e libera o player; não aciona fallback voluntariamente.
- Erros HTTP/player são falhas. Se ElevenLabs falhar, Android continua sendo o fallback.
- Preparação MediaPlayer: watchdog de 15 segundos. Reprodução: duração informada pelo player + 15 segundos. Não há mais corte universal em 20 segundos.
- Android TTS: inicialização limitada a 5 segundos; guarda de reprodução de 30 segundos + 500 ms por caractere. Essa margem conservadora deve ser validada em velocidades de fala diferentes.
- Groq/DeepSeek registram cada chamada e propagam cancelamento. As decisões de roteamento, retries e fallback da IA são as mesmas.

## Eventos de latência

Todos usam relógio monotônico `elapsedRealtime`, identificador `turn` e prefixo `[GABI_LATENCY]`, sem texto do usuário, resposta ou chaves.

| Evento | Significado |
|---|---|
| speech_config | Valores efetivamente enviados ao reconhecedor |
| speech_end_detected | Android informou onEndOfSpeech; não é o fim físico medido da fala |
| speech_final | Resultado final reconhecido, antes de entregá-lo à UI |
| ai_request_start | Início de cada invocação chat/chatWithTools de Groq ou DeepSeek |
| ai_response | Retorno dessa invocação, antes de validação/roteamento |
| ai_error / ai_cancelled | Chamada falhou ou foi cancelada |
| ai_complete | Resultado do fluxo normal do repositório, antes de gravar/falar; pode incluir ferramentas |
| tts_request | Início da solicitação ao motor |
| synthesis_start | Android iniciou síntese, se o motor fornece esse callback |
| audio_available | MP3 completo disponível no ElevenLabs; primeiro chunk no Android, se callback disponível |
| playback_start | MediaPlayer.start / Android onStart; aproximação do começo audível |
| playback_end | Callback normal de conclusão |
| tts_fallback | Falha do ElevenLabs levou ao Android |
| tts_error / tts_cancelled | Falha ou interrupção da fala |

speech_final → playback_start **não inclui todo o tempo de detecção de silêncio**.
Mesmo speech_end_detected é um callback do reconhecedor e não prova o instante real em que a pessoa parou de falar.
Para medir fim físico da fala → primeiro som, grave externamente o usuário e o alto-falante juntos e compare os instantes na gravação. Os callbacks não medem latência física do hardware/Bluetooth.
Os eventos de IA cobrem os providers de conversa Groq/DeepSeek; chamadas internas de skills, como Claude/clima, não recebem eventos HTTP individuais nesta etapa.

## Baseline: dez perguntas

1. Instale o APK de debug compilado. Use o mesmo aparelho, rede, saída de áudio, voz e provider nos dois grupos. Desative notificações proativas durante a medição.
2. Comece pelo grupo A (2.500/1.800 ms): `python ferramentas/configurar_silencio.py --complete 2500 --possible 1800`.
3. Abra o app novamente. Confira `speech_config`. Os overrides são privados ao app e só funcionam no debug; no release os valores originais são usados.
4. Execute `adb logcat -c`, depois `adb logcat -v threadtime GABI_LATENCY:I "*:S" > baseline_A.txt`. Deixe a captura aberta.
5. Faça as dez perguntas abaixo, uma por vez. Aguarde cada resposta acabar. Anote se houve corte, falha, fallback ou áudio ausente. Inclua uma pausa natural em algumas frases.
6. Encerre a captura com Ctrl+C. Execute `python ferramentas/baseline.py baseline_A.txt baseline_A.csv`.
7. Repita como grupo B: `python ferramentas/configurar_silencio.py --complete 1000 --possible 650`. Abra o app novamente e use baseline_B.txt e baseline_B.csv.
8. Compare medianas e máximos, cortes e falhas. Não escolha B só pela menor latência. Motores Android podem ignorar os extras.
9. Volte ao grupo A pelo mesmo comando se B cortar a fala. Não há novo seletor na UI.
10. Registre modelo do celular, Android, provider, voz, rede, Bluetooth e se a primeira interação era cold start. Se houver saudação automática, filtre-a no CSV.

Perguntas sugeridas, começando por “Gabi” quando o modo contínuo exigir:

1. Gabi, como você está?
2. Gabi, o que é uma nuvem?
3. Gabi, me diga uma curiosidade sobre o mar.
4. Gabi, explique o que é gravidade em uma frase.
5. Gabi, me dê uma ideia de almoço simples.
6. Gabi, como posso organizar meu dia?
7. Gabi, qual é a diferença entre ouvir e escutar?
8. Gabi, me conte uma piada curta.
9. Gabi, me explique... [pausa natural] por que o céu é azul.
10. Gabi, me dê três sugestões... [pausa natural] para descansar melhor.

O CSV mantém interações incompletas e canceladas. Não transforme ausência de métricas em zero.
Para fallback, tts_to_playback mede a última tentativa; final_to_playback inclui a espera do motor que falhou.
O script configurar_silencio requer ADB e um APK debuggable; o app é encerrado antes de atualizar suas preferências.

## Verificações adicionais no aparelho

- Interromper durante download e durante fala: não ouvir Android TTS iniciar depois da interrupção.
- Usar uma chave ElevenLabs inválida temporariamente: obter fallback Android e eventos de erro/fallback.
- Resposta com duração superior a 20 segundos: completar sem corte pelo antigo timeout.
- Forçar falha do player/motor: não registrar playback_end como sucesso.
- Observar avatar: aguardar a reprodução em vez de falar durante o download.
- Desativar ElevenLabs: confirmar inicialização e reprodução do Android TTS.
- Verificar uma conversa DirectReply e um comando que exige confirmação: comportamento preservado.

## Próxima etapa

Pare após aplicar, compilar e medir. Nenhuma fase Pocket foi implementada. A compilação e os testes unitários passaram; a validação no aparelho continua pendente.

## APK de debug

O APK foi compilado com as alterações ABC e assinado com a chave de debug deste ambiente. Ele não contém Pocket.
Se a atualização retornar INSTALL_FAILED_UPDATE_INCOMPATIBLE, a instalação existente usa outra chave. Para preservar seus dados, compile o projeto com a mesma chave da instalação anterior; não desinstale sem salvar os dados que precisa manter.
