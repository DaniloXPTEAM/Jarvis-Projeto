"""python baseline.py logcat.txt baseline.csv -- turns without playback are kept."""
import csv,re,sys
from collections import defaultdict

def summarize(lines):
    turns=defaultdict(list)
    for line in lines:
        m=re.search(r'\[GABI_LATENCY\] turn=(\d+) event=(\w+) t_ms=(\d+).*',line)
        if m: turns[m[1]].append((m[2],int(m[3]),line))
    rows=[]
    for tid,ev in turns.items():
        def first(name):return next((t for e,t,_ in ev if e==name),None)
        start=first('playback_start')
        requests=[t for e,t,_ in ev if e=='tts_request' and (start is None or t<=start)]
        responses=[t for e,t,_ in ev if e=='ai_response' and (start is None or t<=start)]
        audio=[t for e,t,_ in ev if e=='audio_available' and (start is None or t<=start)]
        req=requests[-1] if requests else None
        available=next((t for t in audio if req is not None and t>=req),None)
        response=responses[-1] if responses else None
        final=first('speech_final');detected=first('speech_end_detected');ai=first('ai_request_start')
        end=next((t for e,t,_ in ev if e=='playback_end' and start is not None and t>=start),None)
        def delta(a,b):return '' if a is None or b is None else b-a
        rows.append(dict(turn=tid,ai_requests=sum(e=='ai_request_start' for e,_,_ in ev),
            detected_to_final_ms=delta(detected,final),final_to_ai_ms=delta(final,ai),
            ai_to_response_ms=delta(ai,response),response_to_tts_ms=delta(response,req),
            tts_to_audio_ms=delta(req,available),tts_to_playback_ms=delta(req,start),
            final_to_playback_ms=delta(final,start),detected_to_playback_ms=delta(detected,start),
            playback_ms=delta(start,end),status='completed' if end is not None else
            ('cancelled' if any(e=='tts_cancelled' for e,_,_ in ev) else 'incomplete')))
    return rows

if __name__=='__main__':
    rows=summarize(open(sys.argv[1],encoding='utf-8',errors='replace'))
    if not rows:raise SystemExit('Nenhum evento GABI_LATENCY encontrado.')
    with open(sys.argv[2],'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(f'{len(rows)} interações exportadas; filtre status=completed e perguntas por voz.')
