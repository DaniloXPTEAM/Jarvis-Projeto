"""A/B debug. Example: python configurar_silencio.py --complete 1000 --possible 650"""
import argparse,subprocess
p=argparse.ArgumentParser();p.add_argument('--complete',type=int,default=2500);p.add_argument('--possible',type=int,default=1800);a=p.parse_args()
if not 500<=a.complete<=5000 or not 250<=a.possible<=a.complete:p.error('Valores fora da faixa permitida.')
pkg='com.gabi.assistant'
subprocess.run(['adb','shell','am','force-stop',pkg],check=True)
xml=f'<?xml version="1.0" encoding="utf-8"?><map><long name="complete_ms" value="{a.complete}"/><long name="possible_ms" value="{a.possible}"/></map>\n'
subprocess.run(['adb','shell',"run-as com.gabi.assistant sh -c 'mkdir -p shared_prefs && cat > shared_prefs/gabi_speech_ab.xml'"],input=xml.encode(),check=True)
print('Configuração salva. Abra novamente o APK de debug; confira speech_config no Logcat.')
