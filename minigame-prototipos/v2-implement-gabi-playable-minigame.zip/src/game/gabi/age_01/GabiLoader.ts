// ============================================================
// GABI V1 — Loader do modelo definitivo (GLB rigado).
// Enquanto o asset não existir em public/assets/gabi/age_01/,
// retorna null e o GabiController mantém o fallback provisório.
// Quando o GLB chegar: valida esqueleto, extrai AnimationClips e
// entrega tudo pronto para o mixer. Nenhum erro fatal é lançado.
// ============================================================

import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import {
  GABI_V1_GLB_ENABLED,
  EXPECTED_BONES,
  gabiModelPath,
  type GabiStage,
  type GabiOutfit,
} from "./config/gabiStages";

export interface GabiLoadResult {
  root: THREE.Group;
  clips: THREE.AnimationClip[];
  boneNames: string[];
}

/**
 * Carrega o GLB da fase/roupa pedidas.
 * Retorna null (com aviso) se o asset estiver desabilitado ou faltar —
 * o chamador deve então usar a malha provisória.
 */
export async function loadGabiModel(
  stage: GabiStage,
  outfit: GabiOutfit
): Promise<GabiLoadResult | null> {
  if (!GABI_V1_GLB_ENABLED) {
    console.info(`[GabiLoader] GLB desabilitado (GABI_V1_GLB_ENABLED=false) para ${stage}/${outfit}.`);
    return null;
  }
  const url = gabiModelPath(stage, outfit);
  try {
    const gltf = await new GLTFLoader().loadAsync(url);
    const root = gltf.scene as THREE.Group;

    // Varre esqueleto + habilita sombras
    const boneNames: string[] = [];
    let skinned = 0;
    root.traverse((o) => {
      const mesh = o as THREE.SkinnedMesh;
      if (mesh.isSkinnedMesh) {
        skinned++;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
      }
      if ((o as THREE.Bone).isBone) boneNames.push(o.name);
    });
    if (skinned === 0) {
      console.warn(`[GabiLoader] ${url} não contém SkinnedMesh — animações por osso não funcionarão.`);
    }
    const missing = EXPECTED_BONES.filter((b) => !boneNames.includes(b));
    if (missing.length > 0) {
      console.warn(`[GabiLoader] Ossos esperados não encontrados em ${url}: ${missing.join(", ")}`);
    }
    console.info(`[GabiLoader] ${url} carregado: ${gltf.animations.length} clips, ${boneNames.length} ossos.`);
    return { root, clips: gltf.animations, boneNames };
  } catch (err) {
    console.warn(`[GabiLoader] Falha ao carregar ${url} — fallback provisório ativo.`, err);
    return null;
  }
}
