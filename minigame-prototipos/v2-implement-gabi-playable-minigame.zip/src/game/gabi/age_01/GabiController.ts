// ============================================================
// GABI V1 — Controller da personagem.
// Fonte única de verdade entre a ENGINE (estados) e a ANIMAÇÃO:
//   IDLE → WALK → chegada → alinhamento → ação → IDLE.
// Hoje roda em modo PROVISIONAL (malha procedural + ProceduralDriver).
// Quando o GLB chegar (GabiLoader + GABI_V1_GLB_ENABLED), o mesmo
// controller passa a dirigir o AnimationMixer com crossfade — sem
// tocar na engine, na navegação nem nas atividades.
// Cada ação é chamada POR NOME; clipe ausente → warn + idle_breathe.
// ============================================================

import * as THREE from "three";
import type { GabiRig, OutfitLook } from "../../gabiProvisional";
import { buildProvisionalGabi, setOutfitColors } from "../../gabiProvisional";
import { ProceduralDriver, clipForState } from "../../animationLayer";
import type { GabiState } from "../../types";
import { loadGabiModel } from "./GabiLoader";
import { animDef, FALLBACK_CLIP } from "./config/gabiAnimations";
import {
  CURRENT_OUTFIT,
  CURRENT_STAGE,
  STAGE_SCALE,
  type GabiOutfit,
  type GabiStage,
} from "./config/gabiStages";

export type GabiMode = "provisional" | "glb";

export interface GabiInitOptions {
  /** Cores da roupa provisória enquanto o GLB não chega */
  outfitLook: OutfitLook;
  stage?: GabiStage;
  outfit?: GabiOutfit;
}

export class GabiController {
  mode: GabiMode = "provisional";
  root: THREE.Group = new THREE.Group();
  rig: GabiRig | null = null;

  stage: GabiStage = CURRENT_STAGE;
  outfit: GabiOutfit = CURRENT_OUTFIT;

  private driver: ProceduralDriver | null = null;
  private mixer: THREE.AnimationMixer | null = null;
  private actions = new Map<string, THREE.AnimationAction>();
  private currentAction: THREE.AnimationAction | null = null;
  private currentClip: string | null = null;
  private missingWarned = new Set<string>();
  private lastState: GabiState | null = null;

  /**
   * Inicialização SÍNCRONA com fallback provisório — o jogo nunca
   * espera por asset. O upgrade para GLB é opcional e posterior.
   */
  init(opts: GabiInitOptions): this {
    this.stage = opts.stage ?? CURRENT_STAGE;
    this.outfit = opts.outfit ?? CURRENT_OUTFIT;

    const rig = buildProvisionalGabi(opts.outfitLook);
    this.rig = rig;
    this.driver = new ProceduralDriver(rig);
    this.root = rig.group;
    this.root.scale.setScalar(STAGE_SCALE[this.stage]);
    this.mode = "provisional";
    console.info(`[GabiV1] ${this.stage}/${this.outfit} em modo provisório (GLB pendente).`);
    return this;
  }

  /**
   * Tenta substituir a malha provisória pelo GLB definitivo.
   * Retorna true se o upgrade aconteceu; false mantém o provisório.
   * Pode ser chamado a qualquer momento (ex.: após importar o asset).
   */
  async upgradeToGLB(): Promise<boolean> {
    const result = await loadGabiModel(this.stage, this.outfit);
    if (!result) return false;

    // Troca de raiz preservando transform atual
    const { position, rotation } = this.root;
    this.root = result.root;
    this.root.position.copy(position);
    this.root.rotation.copy(rotation);
    this.root.scale.setScalar(STAGE_SCALE[this.stage]);

    this.mixer = new THREE.AnimationMixer(this.root);
    this.actions.clear();
    for (const clip of result.clips) {
      const action = this.mixer.clipAction(clip);
      const def = animDef(clip.name);
      action.loop = def.loop ? THREE.LoopRepeat : THREE.LoopOnce;
      if (!def.loop) action.clampWhenFinished = true;
      this.actions.set(clip.name, action);
    }
    if (this.actions.has(FALLBACK_CLIP)) {
      this.currentAction = this.actions.get(FALLBACK_CLIP)!;
      this.currentAction.play();
      this.currentClip = FALLBACK_CLIP;
    }
    this.mode = "glb";
    console.info(`[GabiV1] Upgrade para GLB concluído (${result.clips.length} clips no mixer).`);
    return true;
  }

  /**
   * Toca uma animação POR NOME com crossfade.
   * Clipe inexistente/PENDING_ASSET → warn único + fallback idle.
   */
  play(clipId: string): void {
    if (this.mode !== "glb" || !this.mixer) return;
    const def = animDef(clipId);
    let target = clipId;
    if (def.status === "PENDING_ASSET" || !this.actions.has(clipId)) {
      if (!this.missingWarned.has(clipId)) {
        this.missingWarned.add(clipId);
        console.warn(`[GabiAnimation] Missing clip: ${clipId} — PENDING_ASSET, fallback ${FALLBACK_CLIP}.`);
      }
      target = FALLBACK_CLIP;
    }
    const next = this.actions.get(target);
    if (!next || next === this.currentAction) return;
    const fade = Math.max(0.12, def.fadeIn);
    if (this.currentAction) this.currentAction.fadeOut(fade);
    next.reset().fadeIn(fade).play();
    this.currentAction = next;
    this.currentClip = target;
  }

  /** Estado da engine → nome de clipe → mixer. Camada única de mapeamento. */
  applyState(state: GabiState): void {
    if (state === this.lastState) return;
    this.lastState = state;
    this.play(clipForState(state));
  }

  // ---- repasses para o driver provisório ----
  setSitting(v: boolean): void { this.driver?.setSitting(v); }
  setLying(v: boolean): void { this.driver?.setLying(v); }
  resetPose(): void { this.driver?.reset(); }
  setOutfit(look: OutfitLook): void { if (this.rig) setOutfitColors(this.rig, look); }

  /** Avanço de frame: mixer (GLB) OU driver procedural (fallback). */
  update(dt: number, time: number, state: GabiState, moving: boolean, reducedMotion: boolean): void {
    this.applyState(state);
    if (this.mode === "glb" && this.mixer) {
      this.mixer.update(dt);
      return;
    }
    this.driver?.update(dt, time, state, moving, reducedMotion);
  }

  get activeClip(): string | null { return this.currentClip; }
}
