// ============================================================
// GABI V1 — Fases de crescimento e roupas.
// Hoje só a Fase 1 (age_01) com o vestido vermelho existe.
// age_02 / age_03 terão mudanças REAIS de design (altura, proporção,
// rosto mais afilado, cabelo), não apenas escala — mas a arquitetura
// já aceita as três sem reescrever a lógica do jogo.
// ============================================================

export type GabiStage = "age_01" | "age_02" | "age_03";

export type GabiOutfit =
  | "red_dress"
  | "blue_pajamas"
  | "study_outfit"
  | "purple_dress";

/** Fase ativa nesta versão do jogo. */
export const CURRENT_STAGE: GabiStage = "age_01";

/** Roupa oficial da V1 (referência principal aprovada). */
export const CURRENT_OUTFIT: GabiOutfit = "red_dress";

/**
 * Escala provisória por fase. Quando age_02/age_03 chegarem como GLB
 * próprios, este valor vira 1 e o design real assume (ver bible §1).
 */
export const STAGE_SCALE: Record<GabiStage, number> = {
  age_01: 1,
  age_02: 1.12,
  age_03: 1.25,
};

export const GABI_ASSET_BASE = "assets/gabi";

export function gabiModelPath(stage: GabiStage, outfit: GabiOutfit): string {
  return `${GABI_ASSET_BASE}/${stage}/gabi_${outfit}.glb`;
}

/**
 * Interruptor do modelo definitivo.
 * VIRE PARA `true` quando `public/assets/gabi/age_01/gabi_red_dress.glb`
 * for entregue. Enquanto false, o GabiController usa a malha provisória
 * procedural — o jogo nunca quebra por falta de asset.
 */
export const GABI_V1_GLB_ENABLED = false;

/** Nomes de nós esperados no GLB (validação de importação). */
export const EXPECTED_BONES = [
  "Hips", "Spine", "Chest", "Neck", "Head",
  "Shoulder.L", "Arm.L", "Hand.L",
  "Shoulder.R", "Arm.R", "Hand.R",
  "Leg.L", "Foot.L", "Leg.R", "Foot.R",
];
