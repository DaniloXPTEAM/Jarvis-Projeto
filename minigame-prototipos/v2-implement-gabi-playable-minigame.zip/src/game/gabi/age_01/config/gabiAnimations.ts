// ============================================================
// GABI V1 — Mapa de animações por NOME (ordem de implementação
// definida pelo cliente): movimentação → postura/atividades → sono.
// Cada entrada aponta para um clipId canônico do manifesto
// (src/game/animationManifest.ts). O status é derivado do manifesto:
// hoje todos PENDING_ASSET (fallback procedural), e viram "ready"
// automaticamente quando o GLB trouxer o take correspondente.
// ============================================================

import { ANIMATION_MANIFEST } from "../../../animationManifest";

/** Mapa solicitado na spec da V1 — chaves ergonômicas → clipId canônico. */
export const GABI_ANIMATIONS = {
  idle: "idle_breathe",
  walk: "walk",
  turnLeft: "turn_left",
  turnRight: "turn_right",
  listen: "idle_look_around",
  present: "happy",
  sitDown: "sit_down",
  standUp: "stand_up",
  read: "read",
  study: "write",
  eat: "eat",
  yawn: "yawn",
  lieDown: "lie_down",
  sleep: "sleep_breathe",
  wakeUp: "wake_up",
} as const;

export type GabiAnimationName = keyof typeof GABI_ANIMATIONS;

export interface GabiAnimDef {
  /** clipId canônico usado pelo mixer */
  clip: string;
  loop: boolean;
  status: "ready" | "PENDING_ASSET";
  fadeIn: number;
  fadeOut: number;
}

const manifestById = new Map(ANIMATION_MANIFEST.map((c) => [c.id, c]));

/** Definições de TODOS os clips do manifesto, indexadas por clipId. */
export const ANIM_DEFS: Record<string, GabiAnimDef> = Object.fromEntries(
  ANIMATION_MANIFEST.map((c) => [
    c.id,
    {
      clip: c.id,
      loop: c.loop,
      status: c.file && c.status === "ready" ? "ready" : "PENDING_ASSET",
      fadeIn: c.fadeIn,
      fadeOut: c.fadeOut,
    } satisfies GabiAnimDef,
  ])
);

/** Clipe de fallback universal. */
export const FALLBACK_CLIP = GABI_ANIMATIONS.idle;

/** Consulta segura: nunca lança, sempre retorna definição. */
export function animDef(clipId: string): GabiAnimDef {
  return ANIM_DEFS[clipId] ?? { clip: FALLBACK_CLIP, loop: true, status: "PENDING_ASSET", fadeIn: 0.4, fadeOut: 0.3 };
}

export { manifestById };
