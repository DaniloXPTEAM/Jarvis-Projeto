# Gabi V1 — Integração no minigame 3D

Integração da personagem V1 sobre o projeto existente. **Nada da engine foi
recriado**: pathfinding, necessidades, ciclo dia/noite, autonomia, save, HUD e
interações continuam intactos. A personagem provisória segue como fallback
oficial até o GLB definitivo chegar.

## Estrutura

```
src/game/gabi/age_01/
  config/gabiStages.ts      # age_01/02/03, outfits, caminho do GLB, flag de ativação
  config/gabiAnimations.ts  # GABI_ANIMATIONS por nome + defs (loop/one-shot/PENDING_ASSET)
  GabiLoader.ts             # GLTFLoader + validação de esqueleto; null seguro se faltar asset
  GabiController.ts         # fonte única engine→animação; crossfade; fallback idle
```

Asset esperado (quando entregue):

```
public/assets/gabi/age_01/gabi_red_dress.glb
```

## Como o controller se liga à engine

```
estado da engine (IDLE/WALK/SIT/EAT/SLEEP…)
   → GabiController.applyState(state)
   → clipForState(state)            (animationLayer.ts)
   → GabiController.play(clipId)    (crossfade 0.2s, one-shot/loop automáticos)
   → mixer (GLB) OU ProceduralDriver (fallback provisório)
```

Deslocamento continua 100% controlado pela navegação (animações in-place,
sem root motion, sem foot sliding). Pontos de interação já existem em
`navigation.ts` (cama, mesa, alimentação, guarda-roupa, banheiro, janela).

## Como adicionar os AnimationClips definitivos

1. Exporte o GLB com esqueleto humanoid e os takes nomeados exatamente como os
   `clipId` do manifesto (`src/game/animationManifest.ts`): `idle_breathe`,
   `walk`, `sit_down`, `eat`, `sleep_breathe`, `wake_up` etc.
2. Coloque em `public/assets/gabi/age_01/gabi_red_dress.glb`.
3. No manifesto, preencha `file: "assets/gabi/age_01/gabi_red_dress.glb"` e
   `status: "ready"` nos takes entregues.
4. Em `gabiStages.ts`, vire `GABI_V1_GLB_ENABLED = true`.
5. Pronto — o `GabiLoader` valida ossos/sombras e o mixer assume com crossfade.
   Takes não entregues continuam `PENDING_ASSET` e caem em `idle_breathe`
   com um único `console.warn` por clipe (sem erro fatal).

## Loop vs one-shot (regra da spec)

- **Loop**: `idle_breathe`, `walk`, `sleep_breathe`, `sit_idle`, `read`, `write`, `eat`…
- **One-shot**: `turn_left/right`, `sit_down`, `stand_up`, `yawn`, `lie_down`,
  `wake_up`, `happy`… (`clampWhenFinished = true`).

## Futuro: age_02 / age_03 e outfits

Cada fase terá GLB próprio com mudanças reais de design (não só escala).
Basta adicionar `public/assets/gabi/age_02/gabi_red_dress.glb` etc. e chamar
`controller` com `stage: "age_02"` — a lógica do jogo não muda. Outfits
(`blue_pajamas`, `study_outfit`, `purple_dress`) seguem o mesmo padrão de
arquivo `gabi_<outfit>.glb`.

## Checklist de teste coberto

- [x] carregamento (inicialização síncrona provisória; loader GLB com try/catch)
- [x] fallback se GLB ausente (flag + `loadGabiModel` → null)
- [x] caminhada com animação e parada com alinhamento de rotação
- [x] interações cama / mesa / alimentação / guarda-roupa / banheiro via pontos
- [x] retorno ao `idle_breathe` após toda ação
- [x] save/load (engine inalterada) · resize · touch
- [x] sem erros fatais no console (apenas `info`/`warn` de status)
