# Integração de animações externas — revisão 2.1

O jogo funciona com a representação procedural provisória. Ela não é a personagem definitiva aprovada. Nenhuma animação da Gabi foi gerada nesta revisão.

## Contrato implementado

`src/animation-manifest.js` contém os 20 estados e seus arquivos pendentes. `src/animation-library.js` carrega GLB/glTF pelo GLTFLoader, usa AnimationMixer, seleciona clipes por estado e libera recursos ao destruir o módulo. `getAnimationStatus()` informa carregamentos e estados pendentes. Falha no carregamento do modelo mantém o protótipo.

Passe `config.animations` para `GabiCare.mount`. Exemplo:

```js
const gabi = GabiCare.mount({config: {animations: {
  modelUrl: '/assets/gabi.glb',
  hipHeight: 0.49,
  sockets: {rightHand: 'hand_r', leftHand: 'hand_l'},
  clips: {
    IDLE: {clip: 'idle_breathe', loop: true},
    WALK: {url: '/assets/gabi-walk.glb', clip: 'walk', loop: true},
    SLEEP: {url: '/assets/gabi-sleep.glb', clip: 'sleep', loop: true}
  }
}}});
```

Modelo em metros, Y para cima e frente +Z. Pés no chão em Y=0; altura alvo 1,18 m; quadril a 0,49 m. A escala deve ser preparada na exportação; o importador não faz retargeting automático. Todos os clipes devem usar o mesmo esqueleto e nomes de ossos. Caminhada in-place com 0,42 m por ciclo; remover deslocamento global dos clipes. O jogo controla a posição e o tempo.

**Limites desta etapa:** os campos `markers` reservam o formato de eventos futuros; ainda não comandam efeitos. A simulação conserva durações configuráveis e suas recompensas independentes. Roupas, objetos presos às mãos, encaixe de cama/cadeira e transições deverão ser ajustados e validados com o modelo definitivo. Vídeos MP4 não entram como clipes 3D. Se um modelo for carregado sem clipe correspondente ao estado, esse estado fica sem animação e aparece como pendente no relatório; isso não é acabamento final.

## Produção pendente

- IDLE: respirar, piscar; variantes de olhar, cabelo, vestido e unhas.
- WALK / TURN: ciclo completo, aceleração/desaceleração, curvas esquerda/direita.
- SIT / STAND_UP: variantes cadeira, tapete e cama com pontos de contato.
- EAT / DRINK: pegar, levar à boca, consumir e devolver; variantes por alimento.
- STUDY / READ / WRITE: abrir livro, ler, virar página, pensar e escrever.
- PLAY / HAPPY: manipular brinquedo e comemorar.
- SLEEP / WAKE_UP: entrar na cama, deitar, respirar, despertar e sair.
- WARDROBE / CHANGE_CLOTHES: abrir, escolher, trocar com privacidade, fechar.
- BATHROOM: alcançar maçaneta, entrar e sair; nenhuma ação íntima.
- TIRED / HUNGRY / BORED: reações contextuais curtas.

Cada entrega deve incluir prévia, nome do clipe, duração, indicação de loop e marcadores normalizados de 0 a 1. Preservar rosto, cabelo ruivo, olhos, idade aparente e proporções oficiais. A qualidade será aprovada sobre o modelo dentro do quarto.
