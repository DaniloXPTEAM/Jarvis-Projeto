# Validação — Gabi Care 2 — 13/09/2026

## Executado

`npm run build` produziu o bundle e o HTML autocontido.

`npm test`: **12 testes da simulação passaram**, seguidos por um teste de geometria/rig que também passou.

A simulação verificou:

1. Todos os pares de pontos de aproximação possuem caminhos; segmentos respeitam obstáculos expandidos pelo raio do corpo.
2. Movimento contínuo não cruza os sólidos nem salta até o destino.
3. Alimentação, bebida, estudo, higiene e banheiro concluem uma vez; cliques repetidos não duplicam recompensa.
4. Jogo de pares depende dos pares reais, rejeita a mesma carta e bloqueia cliques durante um erro.
5. A rotina noturna vai dormir de pijama e acorda pela manhã.
6. Reabrir à noite após ausência carrega Gabi já dormindo, sem XP offline.
7. O relógio avança durante ausências longas, mas o desgaste é limitado; relógio retrocedendo não cria tempo negativo.
8. Retomada curta preserva atividade/roupa; progresso v1 é migrado.
9. Roupas só podem ser escolhidas após a chegada ao guarda-roupa e são persistidas.
10. Interromper estudo sai da cadeira sem recompensa; não se interrompe no interior do banheiro.
11. Dados inválidos básicos não produzem posições/relógios não finitos; os 20 estados pedidos estão presentes.
12. Os cinco períodos do dia e o banheiro autônomo funcionam na simulação.

A geometria verificou:

- Coordenadas finitas das 428 malhas.
- Sequências de estudo, alimentação, sono, banheiro e roupas, executando o mesmo rig usado no jogo.
- Maior deslocamento por amostra a 60 Hz: estudo 0,0133 m; comida 0,0152 m; sono 0,0133 m; banheiro 0,0173 m; roupas 0,0133 m. Nenhum salto acima do limite de 0,10 m do teste.
- Menor distância entre prop segurado e boca durante alimentação: aproximadamente 0,050 m. Isso verifica aproximação, não certifica contato perfeito em todos os alimentos/gestos.
- Articulações independentes de pernas; pálpebras ocultas quando abertas; pivô da porta na parede e rotação de abertura real.

## Inspeção visual disponível

Foram produzidas projeções das malhas reais por um rasterizador de software para examinar a planta e as posições. A primeira projeção com ordenação simples de triângulos gerou artefatos; foi substituída por rasterização com buffer de profundidade. Essa ferramenta é apenas QA geométrico.

A inspeção motivou correções de altura da escrivaninha, proximidade das cadeiras/objetos, orientação das portas do guarda-roupa, posição das pálpebras e detalhes dos olhos. A porta do banheiro possui parede e batente, em vez de uma camada sobre a fotografia.

## Não executado / não aprovado como final

- O navegador recusou tanto a URL local quanto a navegação ao arquivo compartilhado por política de acesso. Nenhuma tentativa de contornar o bloqueio foi feita.
- **Não houve execução do roteiro de UI em WebGL, screenshots reais do jogo, validação de redimensionamento/touch ou medição de FPS no celular.**
- Não houve build de APK nem integração ao aplicativo original, cujo código não foi fornecido.
- A fidelidade exata do rosto/cabelo da Gabi não foi atingida: o modelo é procedural e provisório.
- A animação e os contatos físicos são implementações simplificadas, não um conjunto final de clips produzido/validado para o modelo canônico.

Não confundir testes da simulação e inspeção das malhas com aprovação visual completa do produto.
