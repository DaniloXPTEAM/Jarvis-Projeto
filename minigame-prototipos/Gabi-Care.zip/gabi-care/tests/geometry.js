import assert from 'node:assert/strict';import * as T from 'three';import {createWorld} from '../src/world.js';import sim from '../src/life.cjs';
const {Life,POINTS}=sim;const world=createWorld();let count=0;world.scene.traverse(o=>{if(o.isMesh){count++;const p=o.geometry.attributes.position;for(let i=0;i<p.count;i++)assert(Number.isFinite(p.getX(i))&&Number.isFinite(p.getY(i))&&Number.isFinite(p.getZ(i)))}});assert(count>100);
for(const type of ['study','eat','sleep','bathroom','wardrobe']){const l=new Life(null,{minutesPerSecond:.1});l.request(type,type==='eat'?'pizza':null);let prev=null,maxJump=0,seen=new Set();for(let i=0;i<5000;i++){l.tick(1/60);world.animate(l.s,1/60);world.scene.updateMatrixWorld(true);seen.add(l.s.state);const pos=world.avatar.root.position.clone();if(prev)maxJump=Math.max(maxJump,pos.distanceTo(prev));prev=pos;if(l.s.state==='WARDROBE')l.chooseClothing('school');if(l.s.state==='SLEEP'&&l.s.stateTime>4)l.cancel();if(!l.s.activity)break;}console.log(type,'states',Array.from(seen).join(' → '),'max visible position delta',maxJump.toFixed(4));assert(maxJump<.10,`${type} visible teleport ${maxJump}`);}
// No flat eyelid strip while eyes are open; real independently transformed limb joints.
const l=new Life();world.animate(l.s,.05);assert(world.avatar.lids.every(x=>!x.visible));assert.notEqual(world.avatar.limbs.l.hip,world.avatar.limbs.r.hip);
let nearest=Infinity;l.request('eat','pizza');for(let i=0;i<2500&&l.s.activity;i++){l.tick(1/60);world.animate(l.s,1/60);world.scene.updateMatrixWorld(true);if(l.s.state==='EAT'){const hand=world.avatar.held.getWorldPosition(new T.Vector3()),mouth=world.avatar.mouth.getWorldPosition(new T.Vector3());nearest=Math.min(nearest,hand.distanceTo(mouth))}}console.log('closest held prop to mouth',nearest);assert(nearest<.09);
world.animate({...l.s,state:'BATHROOM',stateTime:1,activity:{type:'bathroom',index:0,steps:[{duration:14}]}},.05);assert(world.door.rotation.y>.5);assert.equal(world.door.position.z,-3.13);console.log('Geometry QA passed,',count,'meshes; navigation, rig, prop reach, and door pivot verified.');

// Wall coverage around the door: no panel across the opening, no gaps around its jambs.
world.scene.updateMatrixWorld(true);
const walls=world.backWall.children.filter(o=>o.isMesh&&['west-pier','door-lintel','middle-pier','window-apron','window-lintel','east-pier'].includes(o.name));
assert.equal(walls.length,6);
const ray=new T.Raycaster();
function wallAt(x,y){ray.set(new T.Vector3(x,y,-2.8),new T.Vector3(0,0,-1));return ray.intersectObjects(walls).length>0;}
assert(!wallAt(1.95,1),'door opening must be empty');
assert(wallAt(1.3,1)&&wallAt(2.6,1)&&wallAt(1.95,2.4),'door must be enclosed by wall and lintel');
assert(world.door.parent.parent===world.backWall,'door belongs to wall hierarchy');
console.log('Bathroom architecture: empty wall opening, piers, lintel and attached door verified.');

// Real AnimationMixer with an in-memory GLTF-shaped fixture: binding, time, missing clip, cleanup.
async function animationImportTest(){
 const {AnimationLibrary}=await import('../src/animation-library.js');
 const carrier=new T.Group(),model=new T.Group(),joint=new T.Bone();joint.name='hand_r';model.add(joint);
 const clip=new T.AnimationClip('IDLE',1,[new T.NumberKeyframeTrack('hand_r.rotation[z]',[0,1],[0,1])]);
 const library=new AnimationLibrary(carrier,{modelUrl:'fixture.glb'});
 library.loader={loadAsync:async()=>({scene:model,animations:[clip]})};
 await library.load();assert.equal(library.report.clips.IDLE,'loaded');assert.equal(library.report.clips.SLEEP,'pending');
 assert.equal(library.socket(),joint);library.update({state:'IDLE',stateTime:.5,stride:0},.2);assert(Math.abs(joint.rotation.z-.5)<.001);
 library.dispose();assert.equal(carrier.children.length,0);console.log('External animation contract: clip binding, time, missing-state report and disposal passed.');
}
animationImportTest().catch(e=>{console.error(e);process.exitCode=1});

for(const [type,state,wait] of [['eat','SIT',.3],['sleep','SLEEP',.4]]){
 const l=new Life(null,{minutesPerSecond:.1});l.request(type,type==='eat'?'pizza':null);
 for(let i=0;i<2000&&l.s.state!==state;i++){l.tick(.05);world.animate(l.s,.05);}
 assert.equal(l.s.state,state);l.tick(wait);world.animate(l.s,.016);
 const before=world.avatar.root.position.clone();assert(l.cancel());world.animate(l.s,0);
 assert(world.avatar.root.position.distanceTo(before)<.02,'interrupted pose must preserve its position');
}
console.log('Interrupted seating and lying-down preserve visible position.');
