# Gabi — Character / Animation Bible v2

Fonte canônica: spritesheet oficial fornecido pelo usuário, especialmente a primeira pose (vestido vermelho). Não confundir as sete poses com frames consecutivos.

Identidade: menina infantil de cabelo ruivo longo e ondulado, olhos grandes castanhos, rosto arredondado, nariz pequeno e sorriso suave. Cabeça grande em proporção ao corpo, braços e pernas curtos, vestido vermelho sem mangas, saia acima dos joelhos e botinhas pretas. Não amadurecer rosto/corpo. Não substituir por adolescente, boneca genérica ou cabelo liso/loiro. Todas as roupas cobrem completamente o corpo.

Paleta de ambiente: sálvia, madeira mel, creme, rosa antigo; luz quente doméstica e janela ampla. Geometria real para parede, batente, soleira, porta, rodapé, móveis e piso. A referência do quarto define identidade, não uma textura de fundo obrigatória.

Escala: Gabi ~1,22 m, quarto 6,8×6,2 m. Apoio em chão y=0; mãos prendem props a juntas. Rig: quadril, tronco, pescoço/cabeça, ombros, cotovelos, mãos, quadris, joelhos, tornozelos; olhar e pálpebras independentes quando o asset permitir. Preferir malha rigada e texturizada derivada da referência pelo Higgsfield/Meshy.

Estados: IDLE, WALK, TURN, SIT, STAND_UP, EAT, DRINK, STUDY, READ, WRITE, PLAY, SLEEP, WAKE_UP, WARDROBE, CHANGE_CLOTHES, BATHROOM, HAPPY, TIRED, HUNGRY, BORED. Transições interpolam juntas, não a opacidade de PNGs. WALK deve usar fase de passada proporcional à distância; pernas alternam apoio e flexão. TURN gira o corpo antes de avançar. Reações de cabelo e tecido são secundárias, não substituem membros articulados.

Estudo: caminho → alinhar → sentar → ler/escrever alternadamente → levantar. Comer/beber: sentar → pegar objeto do prato → levar à boca → devolver objeto → levantar. Guarda-roupa: aproximar → abrir → escolha → troca protegida e sempre vestida → fechar. Banheiro: porta abre → cruza a soleira → fecha → retorna, com o interior sempre oculto. Sono: pijama → cama → sentar → deitar → respirar → acordar → sentar → levantar.

Rotina: 1 segundo real = 1 minuto de jogo por padrão. À noite, preparar pijama e dormir; madrugada carrega em repouso; amanhecer acorda gradualmente. Progresso offline não gera XP repetível. Preferência por animações reais em 3D; jamais apresentar deslocamento de sprite como caminhada.

Critério de fidelidade: o modelo gerado deve ser inspecionado antes de ser declarado fiel. Uma malha procedural provisória não equivale à identidade exata da referência; registrar essa limitação se a geração/rig não estiver disponível.
