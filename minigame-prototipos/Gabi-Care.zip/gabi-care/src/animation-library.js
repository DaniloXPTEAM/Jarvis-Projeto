import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {animationManifest} from './animation-manifest.js';
// Optional external assets. Never submits generation or changes care rewards.
export class AnimationLibrary {
 constructor(carrier,manifest={}){this.carrier=carrier;this.manifest={...animationManifest,...manifest,clips:{...animationManifest.clips,...manifest.clips}};for(const id of Object.keys(this.manifest.clips))this.manifest.clips[id]={...animationManifest.clips[id],...manifest.clips?.[id]};this.actions=new Map();this.report={model:'pending',clips:{}};this.disposed=false;this.loader=new GLTFLoader();}
 async load(){if(!this.manifest.modelUrl)return this.report;try{const gltf=await this.loader.loadAsync(this.manifest.modelUrl);if(this.disposed){this.release(gltf.scene);return this.report}this.model=gltf.scene;this.model.position.y=-this.manifest.hipHeight;this.model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});this.carrier.add(this.model);this.mixer=new T.AnimationMixer(this.model);this.report.model='loaded';
 for(const [id,spec] of Object.entries(this.manifest.clips)){try{const source=spec.url?await this.loader.loadAsync(spec.url):gltf;if(this.disposed){if(source!==gltf)this.release(source.scene);break}const clip=source.animations.find(c=>c.name===spec.clip);if(clip){const action=this.mixer.clipAction(clip);action.setLoop(spec.loop?T.LoopRepeat:T.LoopOnce,spec.loop?Infinity:1);action.clampWhenFinished=true;this.actions.set(id,action);this.report.clips[id]='loaded'}else this.report.clips[id]='pending';if(source!==gltf)this.release(source.scene);}catch{this.report.clips[id]='load-error'}}
 }catch{this.report.model='load-error'}return this.report;}
 update(s,dt=0){if(!this.model||this.disposed)return false;const action=this.actions.get(s.state);this.model.visible=true;
 if(action!==this.current){this.current?.fadeOut(.18);this.current=action;if(action)action.reset().fadeIn(.18).play();}
 this.mixer.update(dt);if(action){const duration=action.getClip().duration;if(!(duration>0))return true;const stepDuration=s.activity?.steps[s.activity.index]?.duration;const phase=s.state==='WALK'?s.stride/(Math.PI*2)*duration:!this.manifest.clips[s.state].loop&&stepDuration&&stepDuration<1000?s.stateTime/stepDuration*duration:s.stateTime;action.time=this.manifest.clips[s.state].loop?phase%duration:Math.min(phase,duration);this.mixer.update(0);}
 // Missing clips remain explicit in report; no fake video/PNG substitute.
 return true;}
 socket(side='rightHand'){return this.model?.getObjectByName(this.manifest.sockets[side]);}
 release(root){root.traverse(o=>{o.geometry?.dispose();for(const m of Array.isArray(o.material)?o.material:o.material?[o.material]:[]){for(const v of Object.values(m))if(v?.isTexture)v.dispose();m.dispose()}})}
 dispose(){this.disposed=true;this.mixer?.stopAllAction();if(this.model){this.mixer.uncacheRoot(this.model);this.model.removeFromParent();this.release(this.model)}this.actions.clear();}
}
