const loops=new Set(['IDLE','WALK','EAT','DRINK','READ','WRITE','PLAY','SLEEP','STUDY','BORED','TIRED','HUNGRY']);
const states=['IDLE','WALK','TURN','SIT','STAND_UP','EAT','DRINK','STUDY','READ','WRITE','PLAY','SLEEP','WAKE_UP','WARDROBE','CHANGE_CLOTHES','BATHROOM','HAPPY','TIRED','HUNGRY','BORED'];
export const animationManifest={version:1,modelUrl:null,units:'metres',upAxis:'Y',forwardAxis:'+Z',height:1.18,hipHeight:.49,locomotion:'in-place',walkMetresPerCycle:.42,
 sockets:{rightHand:'hand_r',leftHand:'hand_l'},
 clips:Object.fromEntries(states.map(id=>[id,{url:null,clip:id,loop:loops.has(id),status:'pending',markers:[]}]))};
