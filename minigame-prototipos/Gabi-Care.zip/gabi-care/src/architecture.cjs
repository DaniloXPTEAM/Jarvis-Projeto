'use strict';
// One measured opening drives the wall, frame, leaf and approach point.
const BATHROOM={wallZ:-3.13,wallDepth:.18,wallHeight:2.9,left:1.4,right:2.5,height:2.26,leafWidth:1.04,leafHeight:2.20,hingeX:1.43,hingeZ:-3.13,approach:{x:1.95,z:-2.65,yaw:Math.PI}};
const WINDOW={left:-1.45,right:.3,bottom:1.1,top:2.56};
function backWallSegments(){const d=BATHROOM,w=WINDOW;return [
 {id:'west-pier',left:-3.48,right:w.left,bottom:0,top:d.wallHeight},
 {id:'door-lintel',left:d.left,right:d.right,bottom:d.height,top:d.wallHeight},
 {id:'middle-pier',left:w.right,right:d.left,bottom:0,top:d.wallHeight},
 {id:'window-apron',left:w.left,right:w.right,bottom:0,top:w.bottom},
 {id:'window-lintel',left:w.left,right:w.right,bottom:w.top,top:d.wallHeight},
 {id:'east-pier',left:d.right,right:3.48,bottom:0,top:d.wallHeight}
];}
module.exports={BATHROOM,WINDOW,backWallSegments};
