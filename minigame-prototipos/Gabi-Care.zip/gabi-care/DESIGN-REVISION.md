# Análise anterior à reconstrução

1. A versão anterior usa uma fotografia de quarto como plano único. Não existem paredes/móveis geométricos, áreas de uso ou colisões reais.
2. A porta é um retângulo CSS sobre a fotografia: não existe abertura na parede nem percurso para cruzar a soleira.
3. Gabi é uma imagem trocada e deslocada por porcentagens; não tem articulações, passos ou alinhamento físico com móveis.
4. A noite é uma camada escura; o céu não muda e a rotina offline é apenas pausada.

Decisão: reconstruir o ambiente com geometria 3D, preservando sálvia, madeira quente, creme, rosa, cama à esquerda e mesa à direita. A referência fotográfica e os recortes ficam preservados como fontes, mas deixam de compor o cenário jogável.

Planta: quarto 6,8×6,2 m, parede de fundo em z=-3,1. Cama na lateral esquerda; mesa/escrivaninha na direita ao fundo; guarda-roupa na direita à frente; mesa pequena de alimentação à esquerda à frente; tapete no centro. Banheiro no fundo à esquerda do vão da janela, com corredor de aproximação. Abertura da porta é parte da malha da parede. Rodapé dividido nos limites dos vãos. Camera de casa de boneca, parede frontal omitida para visibilidade.

Navegação: A* em grade com obstáculos expandidos pelo raio do corpo; movimento contínuo, aceleração/frenagem e alinhamento de direção. Locais de interação ancorados em coordenadas de mundo, com pontos de aproximação e assento. As transições especiais (sentar/deitar/soleira) pertencem à atividade e não usam caminho através de um obstáculo.

Tempo: 1 minuto simulado por segundo real; relógio persistido com data absoluta em minutos. Necessidades por hora simulada; simulação offline limitada e sem XP. À noite, vestir pijama e dormir autonomamente. Ao carregar de madrugada após ausência significativa, Gabi aparece no leito, sem animação de teletransporte observável.

Animação: rig procedural hierárquico em 3D e interpolação de juntas, mãos com prop ancorado, pálpebras e olhar. Identidade exata depende de asset rigado consistente. Catálogo Higgsfield oferece Meshy, mas nesta sessão a ferramenta generate_3d não está exposta; a chamada de estimativa confirma que não é executável por generate_image. Não afirmar que uma personagem procedural preserva exatamente o rosto do spritesheet.
