# Revisão 2.1 — porta na parede e animações externas

Alterações executadas no módulo disponível `gabi-care`:

- Parede posterior recomposta a partir de segmentos contíguos e duas aberturas: porta e janela.
- Porta é filha da parede na cena. Batentes, verga, folha, dobradiças e soleira usam a mesma especificação em `src/architecture.cjs`.
- Rodapé interrompido no vão; recessos externos permitem abertura sem invadir o corredor.
- Caminho até o banheiro preservado; nenhuma porta PNG é utilizada nesta versão 3D.
- Importação opcional de modelo e animações GLB/glTF; catálogo explícito dos 20 estados pendentes.
- Correção: `durations.study` agora controla a soma das etapas de estudo, antes fixadas no código.

Validação: 12 testes de simulação, testes de geometria/transições, cobertura da parede ao redor do vão e contrato de importação com AnimationMixer. Inspeção geométrica por renderização de software. Esta imagem não prova iluminação WebGL nem desempenho no celular. Teste visual em navegador e no APK continua pendente.

Integração: não foi localizado o aplicativo original da Gabi. O Higgsfield retornou apenas o jogo de carro Luciane. Este pacote atualiza o módulo disponível, NÃO o aplicativo instalado no celular. Para aplicar no aplicativo, é necessário seu código-fonte ou acesso ao projeto correto. Não há backend; persistência local ou adaptador de armazenamento fornecido pelo app.

Animação final, fidelidade visual da personagem, adaptação das roupas e encaixe dos clipes definitivos continuam pendentes conforme ANIMACOES-EXTERNAS.md.

Nova referência recebida: porta de madeira à direita da janela, cama à esquerda, escrivaninha deslocada 1,30 m para a frente para liberar a aproximação. A imagem guia a disposição do cenário 3D; não foi usada como simples fundo. A aparência 3D continua sendo um protótipo e não reproduz o acabamento fotográfico da referência. Saves anteriores à mudança de planta mantêm necessidades/evolução e encerram atividades incompatíveis com a planta antiga, sem recompensas adicionais.
