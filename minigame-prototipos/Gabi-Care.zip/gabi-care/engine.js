/* Gabi Care — deterministic simulation, browser + Node. No network dependency. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.GabiSimulation=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const CONFIG={version:1,travel:1.6,returnTravel:1.5,durations:{eat:7,study:24,sleep:50,bathroom:7},decayPerHour:{hunger:6,energy:4,fun:5,bathroom:7},offlineMaxHours:6,offlineMaxChange:30,offlineFloor:15,stages:[0,60,160],sleepPerSecond:1.25};
const FOODS={fruit:{name:'Frutinhas',emoji:'🍓',gain:22},sandwich:{name:'Sanduíche',emoji:'🥪',gain:32},soup:{name:'Sopinha',emoji:'🥣',gain:38}};
const clamp=(n,lo=0,hi=100)=>Math.max(lo,Math.min(hi,n));
const num=(v,d)=>typeof v==='number'&&Number.isFinite(v)?v:d;
const copy=o=>JSON.parse(JSON.stringify(o));
function fresh(now=Date.now()){return {version:1,needs:{hunger:65,energy:72,fun:60,learning:10,bathroom:35},xp:0,completed:{eat:0,study:0,play:0,sleep:0,bathroom:0},prefs:{muted:true,reduced:false},activity:null,lastSeen:now,message:'Oi! Que bom ter você aqui.',lastNotice:0,noticeClock:0};}
class Engine{
 constructor(saved,config={}){this.config={...CONFIG,...config,durations:{...CONFIG.durations,...config.durations},decayPerHour:{...CONFIG.decayPerHour,...config.decayPerHour}};this.s=fresh();this.events=[];if(saved)this.restore(saved);}
 restore(saved){let o;try{o=typeof saved==='string'?JSON.parse(saved):saved}catch{return}if(!o||o.version!==1)return;const n=fresh();for(const k in n.needs)n.needs[k]=clamp(num(o.needs?.[k],n.needs[k]));n.xp=clamp(num(o.xp,0),0,1e7);for(const k in n.completed)n.completed[k]=clamp(num(o.completed?.[k],0),0,1e7);n.prefs={muted:o.prefs?.muted!==false,reduced:o.prefs?.reduced===true};n.lastSeen=num(o.lastSeen,Date.now());n.message='Que bom que voltou!';const a=o.activity;if(a&&['eat','study','play','sleep','bathroom'].includes(a.type)&&['walking','doing','returning'].includes(a.phase)&&Number.isFinite(a.elapsed)&&a.elapsed>=0){
 const validFood=a.type!=='eat'||Object.hasOwn(FOODS,a.food);
 const validBoard=a.type!=='play'||(Array.isArray(a.board)&&a.board.length===8&&[0,1,2,3].every(v=>a.board.filter(x=>x===v).length===2)&&Array.isArray(a.matched)&&a.matched.every(x=>Number.isInteger(x)&&x>=0&&x<8)&&new Set(a.matched).size===a.matched.length&&[0,1,2,3].every(v=>a.matched.filter(i=>a.board[i]===v).length%2===0));
 if(validFood&&validBoard)n.activity={type:a.type,phase:a.phase,elapsed:Math.min(a.elapsed,3600),food:a.food,duration:a.type==='play'?0:this.config.durations[a.type],board:a.board||[],matched:a.matched||[],selected:[],lock:0,success:a.success===true,studyFactor:clamp(num(a.studyFactor,1),0.5,1),sleepEarned:clamp(num(a.sleepEarned,0),0,100)};
 }this.s=n;}
 stage(){return this.s.xp>=this.config.stages[2]?2:this.s.xp>=this.config.stages[1]?1:0;}
 say(text){this.s.message=text;}
 resume(now=Date.now()){const hrs=clamp((now-this.s.lastSeen)/3600000,0,this.config.offlineMaxHours);for(const [k,rate]of Object.entries(this.config.decayPerHour)){const d=Math.min(this.config.offlineMaxChange,hrs*rate);this.s.needs[k]=k==='bathroom'?clamp(this.s.needs[k]+d):Math.max(Math.min(this.config.offlineFloor,this.s.needs[k]),this.s.needs[k]-d)}this.s.lastSeen=now;}
 snapshot(now=Date.now()){this.s.lastSeen=now;return copy(this.s)}
 start(type,food='fruit',random=Math.random){if(this.s.activity)return false;const n=this.s.needs;if(!['eat','study','play','sleep','bathroom'].includes(type))return false;
 if(type==='eat'&&(!Object.hasOwn(FOODS,food)||n.hunger>=90)){this.say('Minha barriguinha já está satisfeita.');return false}
 if((type==='study'||type==='play')&&n.energy<20){this.say('Estou com soninho. Vamos descansar primeiro?');return false}
 if(type==='study'&&n.hunger<20){this.say('Um lanchinho antes de estudar?');return false}
 if(type==='sleep'&&n.energy>=98){this.say('Já estou descansada! Vamos brincar?');return false}
 if(type==='bathroom'&&n.bathroom<15){this.say('Agora não preciso. Eu aviso!');return false}
 let board=[0,0,1,1,2,2,3,3];for(let i=7;i>0;i--){const j=Math.floor(random()*(i+1));[board[i],board[j]]=[board[j],board[i]]}
 this.s.activity={type,phase:'walking',elapsed:0,duration:this.config.durations[type]||0,food,board,matched:[],selected:[],lock:0,success:false,studyFactor:n.fun<25?0.65:1,sleepEarned:0};
 this.say({eat:'Vou buscar meu lanchinho!',study:'Hora de descobrir coisas novas!',play:'Vamos encontrar os pares?',sleep:'Vou colocar meu pijaminha…',bathroom:this.stage()===2?'Já sei ir sozinha. Já volto!':'Você me acompanha até a porta?'}[type]);return true;}
 flip(i){const a=this.s.activity;if(!a||a.type!=='play'||a.phase!=='doing'||a.lock>0||!Number.isInteger(i)||i<0||i>=8||a.matched.includes(i)||a.selected.includes(i))return false;a.selected.push(i);if(a.selected.length===2){const [x,y]=a.selected;if(a.board[x]===a.board[y]){a.matched.push(x,y);a.selected=[];this.events.push('pair');if(a.matched.length===8){a.success=true;a.phase='returning';a.elapsed=0;this.say('Encontramos todos os pares!')}}else a.lock=0.8;}return true;}
 cancel(){const a=this.s.activity;if(!a)return false;if(a.phase==='returning')return false;a.success=a.type==='sleep'&&a.sleepEarned>=10;a.phase='returning';a.elapsed=0;this.say(a.type==='sleep'?'Bom dia! Já vou levantar.':'Tudo bem, podemos tentar depois.');return true;}
 complete(){const a=this.s.activity;if(!a)return;this.s.activity=null;if(!a.success)return;const n=this.s.needs;let xp=0;switch(a.type){case'eat':n.hunger=clamp(n.hunger+FOODS[a.food].gain);n.bathroom=clamp(n.bathroom+8);xp=10;break;case'study':n.learning=clamp(n.learning+12*a.studyFactor);xp=16;break;case'play':n.fun=clamp(n.fun+30);n.energy=clamp(n.energy-4);xp=14;break;case'bathroom':n.bathroom=5;xp=10;break;case'sleep':xp=12;break;}const old=this.stage();this.s.xp+=xp;this.s.completed[a.type]++;this.events.push('complete');this.say(old!==this.stage()?'Estou crescendo! Já consigo fazer mais coisas.':{eat:'Que gostoso! Obrigada pelo carinho.',study:'Aprendi uma coisa nova! Vamos praticar depois?',play:'Você encontrou os pares comigo! Adorei!',sleep:'Estou descansada. Que dia bonito!',bathroom:'Prontinho! Vamos continuar?'}[a.type]);}
 tick(seconds){let dt=clamp(num(seconds,0),0,60);const n=this.s.needs;for(const [k,rate]of Object.entries(this.config.decayPerHour)){n[k]=clamp(n[k]+(k==='bathroom'?1:-1)*rate*dt/3600)}this.s.noticeClock+=dt;
 let a=this.s.activity;if(a){if(a.lock>0){a.lock=Math.max(0,a.lock-dt);if(a.lock===0)a.selected=[]}let budget=dt;for(let guard=0;a&&budget>0&&guard<5;guard++){
 const limit=a.phase==='walking'?this.config.travel:a.phase==='returning'?this.config.returnTravel:a.type==='play'?Infinity:a.duration;
 const used=Math.min(budget,Math.max(0,limit-a.elapsed));
 if(a.phase==='doing'&&a.type==='sleep'){const gain=Math.min(100-n.energy,used*this.config.sleepPerSecond);n.energy+=gain;a.sleepEarned+=gain;}
 if(a.phase==='doing'&&a.type==='study')n.energy=clamp(n.energy-used*0.2);
 a.elapsed+=used;budget-=used;
 if(a.elapsed>=limit){a.elapsed=0;if(a.phase==='walking'){a.phase='doing';this.say({eat:'Hmm… uma pausa gostosa!',study:'Lendo e aprendendo…',play:'Toque nas cartas e encontre os pares.',sleep:'Zzz…',bathroom:'Já volto!'}[a.type])}else if(a.phase==='doing'){a.phase='returning';a.success=true;this.say(a.type==='bathroom'?'Prontinho, estou voltando!':'Terminei! Já vou voltar.')}else{this.complete();a=null;}}else break;
 }}else if(this.stage()===2&&n.bathroom>=75){this.start('bathroom')}else if(this.s.noticeClock-this.s.lastNotice>=45){this.s.lastNotice=this.s.noticeClock;const line=n.bathroom>65?'Preciso ir ao banheiro. Você me ajuda?':n.energy<30?'Estou com soninho':n.hunger<35?'Minha barriguinha está com fome':n.fun<35?'Vamos brincar?':n.learning<25?'Hora de estudar?':['Que tal uma brincadeira?','Gosto quando você vem me visitar.','Olha como meu quarto é aconchegante!'][Math.floor(Math.random()*3)];this.say(line)}
 }
}
return {Engine,CONFIG,FOODS,fresh};
});
