# Gabi Care 2 — quarto e rotina em 3D

Versão de desenvolvimento que reconstrói o módulo anterior. **Não é uma entrega final de fidelidade visual**: a Gabi articulada é uma aproximação geométrica, e não o modelo exato da referência. O funcionamento WebGL no celular e a integração ao APK ainda precisam ser validados.

## Experimentar

Abra `Jogar-Gabi.html` em um navegador com WebGL. Esse arquivo contém o código e os recursos usados pela demonstração, sem precisar de rede para jogar. No Android, o visualizador do gerenciador de arquivos pode não executar HTML/WebGL; use o navegador ou integre à WebView do aplicativo.

Para desenvolvimento:

```
npm ci
npm run build
npm test
npm start
```

Abra `http://localhost:8080`. O botão **Cuidar da Gabi** abre o módulo; **Voltar** salva e fecha. Arraste para girar a câmera, use dois dedos para aproximar ou os botões de câmera. Toque nos móveis ou nas ações para iniciar atividades.

## O que mudou

- A fotografia deixou de ser o cenário jogável. O quarto agora é geometria 3D: piso, paredes, vãos, janela, porta, móveis e iluminação compartilham coordenadas e perspectiva.
- A porta do banheiro pertence a um vão da parede, com batente, soleira, rodapé interrompido, folha articulada e maçaneta. Um anteparo opaco protege a privacidade; o interior nunca aparece.
- A* em grade com obstáculos expandidos pelo raio da personagem. Cada atividade possui ponto de aproximação; o código evita os volumes da cama, mesas, cadeiras e guarda-roupa durante a caminhada.
- Rig hierárquico em 3D com quadris, joelhos, braços, cotovelos, mãos, cabeça e pálpebras. Passadas acompanham distância percorrida. Juntas mudam durante as atividades; não se usam PNGs deslizando ou balançando como personagem.
- Mãos usam IK de dois segmentos para alcançar alimento e material de estudo. Os objetos segurados são filhos da mão.
- Relógio de jogo persistente: **1 segundo real = 1 minuto de jogo** por padrão; um dia completo dura 24 minutos. Manhã, dia, fim de tarde, noite e madrugada modificam céu, sol/lua/estrelas e intensidades/cores das luzes.
- À noite, Gabi vai ao guarda-roupa, troca para pijama, caminha à cama, senta, deita e dorme. Ao amanhecer, acorda, levanta e pode trocar de roupa.
- Ao reabrir após ausência significativa, o relógio avança e a rotina é recuperada: durante a madrugada, Gabi aparece já deitada, de pijama e dormindo. Não é preciso assistir a um reposicionamento.
- Saciedade, energia, higiene, banheiro, diversão, aprendizado e humor. Alimentação, bebidas, roupas persistentes, estudo alternando leitura/escrita, jogo de pares e autonomia progressiva.
- O progresso da versão 1 é migrado sem apagar a chave anterior. A versão antiga dos arquivos principais está em `v1-backup`.

## Arquivos principais

- `src/life.cjs`: relógio, estados, necessidades, progressão, navegação, persistência e migração.
- `src/world.js`: arquitetura, móveis, rig, animação, iluminação e áreas de interação.
- `src/main.js`: módulo isolado, interface, câmera, entrada, salvar/abrir/fechar.
- `src/style.css`: interface responsiva.
- `gabi-care.js`: bundle pronto, incluindo Three.js.
- `build.cjs`: gera o bundle e a demonstração autocontida.
- `CHARACTER-ANIMATION-BIBLE.md`: identidade, proporções e regras de animação.
- `DESIGN-REVISION.md`: diagnóstico da versão anterior e decisões de reconstrução.
- `VALIDACAO.md`: evidências e limites dos testes executados.

## Integração ao aplicativo

O aplicativo original não foi fornecido. A integração está demonstrada em `index.html`; **nenhum APK foi compilado**.

```html
<script>window.GABI_ART_URL = '/gabi/assets/sunflower.png';</script>
<script src="/gabi/gabi-care.js"></script>
<button id="care">Cuidar da Gabi</button>
<script>
const gabi = GabiCare.mount({userId: 'ID_ESTAVEL_DO_USUARIO'});
document.querySelector('#care').onclick = () => gabi.open();
</script>
```

API: `open()`, `close()`, `save()`, `destroy()`. Para remover com gravação concluída: `await gabi.close(); gabi.remove()`. Eventos: `gabi-open`, `gabi-close` com `detail.saved`, `gabi-save-error`. O host deve tornar seu conteúdo anterior inerte enquanto o jogo estiver aberto; o exemplo faz isso.

Para reutilizar os serviços existentes:

```js
const gabi = GabiCare.mount({
  userId: session.user.id,
  storage: {
    load: () => appStorage.loadGabi(session.user.id),
    save: state => appStorage.saveGabi(session.user.id, state)
  }
});
```

`session` e `appStorage` são pontos de conexão ao seu aplicativo, não serviços incluídos. Ao trocar de conta, feche e remova a instância anterior.

Por padrão, usa `localStorage`, chave `gabi-care:v2:<userId>`, sem sincronização ou backend. Lê a chave v1 quando v2 não existe. Gravações são serializadas e não sobrescrevem os dados anteriores quando o carregamento falha. Duas abas simultâneas podem sobrescrever progresso: usar uma instância por usuário. O salvamento assíncrono de um backend pode não terminar se o sistema matar o app; o host nativo deve salvar em seu ciclo de vida. Nenhum dado é enviado durante o jogo.

Capacitor/Cordova: copiar o bundle e assets para a aplicação web. Android nativo: servir por `WebViewAssetLoader`, habilitar JavaScript/DOM storage e mapear Voltar para `close()`. O host deve notificar pausa/retomada se sua WebView não propagar `visibilitychange`.

## Configuração

```js
const gabi = GabiCare.mount({config: {
  minutesPerSecond: 1,
  walkSpeed: 0.8,
  offlineHours: 48,
  decay: {hunger: 3.2, energy: 3.4, hygiene: 1.7, bathroom: 4, fun: 2.8},
  durations: {eat: 15, drink: 8, read: 22, bathroom: 10, hygiene: 12},
  stages: [0, 60, 160]
}});
```

`decay` representa pontos por **hora de jogo**, durações são segundos reais. O estudo é uma sequência de leitura/escrita definida em `Life.request()`. A aparência do céu é definida em `lighting()`; caminhos, obstáculos e destinos estão em `SOLIDS` e `POINTS`. `CHAIR_POINT` é uma âncora de assento, não destino navegável. Para mudar a planta, ajuste as malhas e os volumes correspondentes juntos.

O relógio avança pelo tempo integral ausente. A queda de necessidades é limitada a 32 pontos por retorno e tem piso acolhedor; aprendizado e XP não se deterioram. Ausências acima de 60 segundos reconstroem uma rotina plausível, sem simular nem recompensar cada atividade offline. Ausências menores retomam a atividade salva. Isso é uma aproximação de continuidade, não uma simulação segundo a segundo de dias ausentes.

## Limitações reais

- **Identidade exata da Gabi não resolvida.** O modelo atual é procedural, com cabelo ruivo, olhos castanhos grandes e vestido vermelho, mas rosto, cabelo e acabamento diferem do spritesheet. Precisa ser substituído por uma malha fiel e rigada para cumprir integralmente a solicitação.
- Animação articulada procedural, sem captura de movimento, física completa de cabelo/tecido ou deformação facial sofisticada. Roupas usam formas e cores simples; não reproduzem todos os detalhes das referências.
- Comer/beber, segurar lápis e sentar são aproximações geométricas. Não há manipulação individual dos dedos, mastigação realista, virar páginas completo ou um sistema universal de contato físico. Nem todos os gestos pedidos têm animação específica final.
- Os alimentos são representações simplificadas; a mesa não reconstitui fielmente cada prato escolhido. O jogo de pares acontece em uma interface, enquanto Gabi permanece sentada no tapete.
- Colisões validam a navegação do corpo no piso. Sentar, deitar e cruzar a soleira usam trajetórias específicas da atividade; não existe um simulador físico geral de todos os membros/móveis.
- O código mira 30 renderizações/s no celular, limita resolução e atualiza sombras a 10 Hz. **FPS, bateria e memória não foram medidos em aparelho real.**
- Não houve QA do WebGL por navegador nesta sessão: o acesso ao projeto local foi bloqueado pela política do navegador. As imagens de `qa/` são projeções geométricas por software, sem reproduzir o resultado WebGL final.

## Higgsfield

O quadro de girassol usado como textura em uma moldura 3D foi gerado com `gpt_image_2`, job `9645aff3-8b85-44b9-9c43-c1beae63fa67`, e está incorporado ao HTML. Não se usa vídeo do quarto.

O catálogo também listou Meshy Image to 3D com rig e animação, mas a ferramenta `generate_3d` não está disponível nesta sessão; `estimate_image_cost` recusou o modelo 3D e informou a ferramenta necessária. Portanto, **nenhum modelo rigado da Gabi foi gerado pelo Higgsfield**. A limitação anterior do Seedance também não foi resolvida. Não foi necessário comprar ou alterar plano.
