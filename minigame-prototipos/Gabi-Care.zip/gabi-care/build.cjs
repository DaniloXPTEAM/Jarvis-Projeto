const fs=require('fs'),path=require('path'),esbuild=require('esbuild');
const root=__dirname;
esbuild.buildSync({entryPoints:[path.join(root,'src/main.js')],bundle:true,outfile:path.join(root,'gabi-care.js'),format:'iife',loader:{'.css':'text'},minify:true,sourcemap:true});
esbuild.buildSync({entryPoints:[path.join(root,'tests/geometry.js')],bundle:true,platform:'node',format:'cjs',outfile:path.join(root,'qa/geometry-test.cjs')});
const uri=p=>'data:image/png;base64,'+fs.readFileSync(path.join(root,p)).toString('base64');
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');html=html.replace('src="assets/idle.png"','src="'+uri('assets/idle.png')+'"').replace('window.GABI_ART_URL="assets/sunflower.png"','window.GABI_ART_URL="'+uri('assets/sunflower.png')+'"');let js=fs.readFileSync(path.join(root,'gabi-care.js'),'utf8').replace(/\/\/# sourceMappingURL=.*$/m,'');
html=html.replace('<script src="gabi-care.js"></script>','<script>'+js.replace(/<\/script/gi,'<\\/script')+'</script>');fs.writeFileSync(path.join(root,'Jogar-Gabi.html'),html);console.log('Built self-contained 3D demo:',Buffer.byteLength(html),'bytes');
