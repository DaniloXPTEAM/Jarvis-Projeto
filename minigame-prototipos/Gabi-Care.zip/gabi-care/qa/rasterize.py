# Geometric software QA renderer. No browser, no WebGL, no measured FPS.
import sys,json,numpy as np
from PIL import Image
name=sys.argv[1]
faces=json.load(open('gabi-care/qa/'+name+'-triangles.json'))
size=900
img=np.empty((size,size,3),np.uint8);img[:]=[236,225,211]
depth=np.full((size,size),np.inf)
for f in faces:
 p=np.array(f['p']);lo=np.maximum(0,np.floor(p[:,:2].min(0)).astype(int));hi=np.minimum(size-1,np.ceil(p[:,:2].max(0)).astype(int))
 if np.any(hi<lo):continue
 (x0,y0,z0),(x1,y1,z1),(x2,y2,z2)=p
 den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
 if abs(den)<1e-9:continue
 yy,xx=np.mgrid[lo[1]:hi[1]+1,lo[0]:hi[0]+1];xx=xx+.5;yy=yy+.5
 a=((y1-y2)*(xx-x2)+(x2-x1)*(yy-y2))/den;b=((y2-y0)*(xx-x2)+(x0-x2)*(yy-y2))/den;c=1-a-b
 z=a*z0+b*z1+c*z2;view=depth[lo[1]:hi[1]+1,lo[0]:hi[0]+1];mask=(a>=-1e-6)&(b>=-1e-6)&(c>=-1e-6)&(z<view)
 view[mask]=z[mask];color=[int(f['color'][i:i+2],16)for i in [1,3,5]];img[lo[1]:hi[1]+1,lo[0]:hi[0]+1][mask]=color
Image.fromarray(img).save('gabi-care/qa/'+name+'.png')
print('rendered',name)
