# Roteiro pendente de teste no aplicativo / navegador real

1. Abrir pelo botão, aproximar/girar a câmera e tocar nos móveis. Confirmar que objetos atrás de paredes/móveis não recebem o clique.
2. Alimentar com cada opção; observar aproximação, assento, mão, boca, prato e retorno. Verificar os contatos quadro a quadro.
3. Estudar: alinhar/sentar/ler/escrever/levantar; observar altura da mesa, mãos e pés.
4. Resolver os pares e tentar cliques rápidos, repetidos e pares incorretos. Fechar com partida pela metade e reabrir.
5. Escolher cada roupa disponível e reabrir. Observar articulação das portas e cobertura constante do corpo.
6. Banheiro e higiene: verificar a entrada, privacidade, abertura/fechamento e retorno, sem atravessar a parede.
7. Deixar o relógio passar de 17:30 até a noite: guarda-roupa, pijama, caminho, cama e respiração.
8. Fechar durante a noite por mais de 60 segundos e reabrir. Confirmar sono imediato. Aguardar amanhecer e acompanhar despertar/roupa do dia.
9. Testar telas 320×640, 390×844, 844×390 e desktop; verificar ações acessíveis, foco/Tab/Escape e preferência de movimento reduzido.
10. Medir FPS, bateria/memória e ociosidade após fechar/ocultar em um Android real. Verificar retorno pelo botão físico, perda/restauração de contexto WebGL, falha de armazenamento e troca de conta.

Este roteiro foi fornecido para a próxima validação. Não foi executado como teste WebGL nesta sessão.
